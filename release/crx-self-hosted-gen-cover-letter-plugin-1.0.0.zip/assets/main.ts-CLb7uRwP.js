import{c as e,f as t,i as n,l as r,n as i,p as a,s as o,t as s}from"./resolveVacancyForGeneration-CTr_BeoK.js";import{T as ee,c as te,g as c,i as l,u,w as d}from"./statusStorage-CgwhPeLn.js";import{O as f,_ as p,a as m,b as ne,c as h,d as g,f as _,g as v,l as re,m as y,r as b,s as ie,u as x,w as ae}from"./classifyStateStorage-CBx7elDP.js";function oe(e,t){let n=e.trim(),r=t.trim();return r?n?`${n}\n\n${r}`:r:n}function se(e){return e.experience.length===0?`Нет данных`:e.experience.map(e=>{let t=[e.startDate,e.endDate].filter(Boolean).join(` — `),n=e.description.trim();return[`${e.position} в ${e.company}`,t?`Период: ${t}`:``,n?`Описание: ${n}`:``].filter(Boolean).join(`
`)}).join(`

`)}function ce(e){return e.education.length===0?`Нет данных`:e.education.map(e=>[e.organization,e.degree,e.speciality].filter(Boolean).join(`, `)).join(`
`)}function le(e){return e.projects.length===0?`Нет данных`:e.projects.map(e=>{let t=e.link?`\nСсылка: ${e.link}`:``;return`${e.name}\n${e.description}${t}`}).join(`

`)}function S(e){return e.certifications.length===0?`Нет данных`:e.certifications.map(e=>`${e.name}: ${e.description}`).join(`
`)}function C(e){return[`Должность: ${e.title}`,`Источник: ${e.source}`,`Язык резюме: ${e.language}`,e.selfAbout?`О себе:\n${e.selfAbout}`:``,`Навыки: ${e.skills.length>0?e.skills.join(`, `):`Нет данных`}`,`Опыт работы:\n${se(e)}`,`Образование:\n${ce(e)}`,`Проекты:\n${le(e)}`,`Сертификаты и курсы:\n${S(e)}`].filter(Boolean).join(`

`)}function w(e,t){let n=`Резюме кандидата:
"""
${C(e)}
"""`;return t?.text.trim()?`${n}

Текст вакансии:
"""
${t.text}
"""

${T}`:`${n}

Текст вакансии не предоставлен.

${T}`}var T=`Напиши сопроводительное письмо по инструкциям выше. Язык письма — как у основной части текста вакансии; если вакансии нет — как у резюме.`;function E({generationPrompt:e,resume:t,vacancy:n}){let r=[],i=e.trim();return i&&r.push({role:`developer`,content:i}),r.push({role:`user`,content:w(t,n)}),r}var D=/^(?:ключевые навыки|требования|обязанности|условия|о компании|мы предлагаем)\s*$/i;function O(e){let t=e.replace(/\r\n/g,`
`).split(`
`);for(;t.length>0&&D.test(t[0].trim());)for(t.shift();t.length>0&&t[0].trim()===``;)t.shift();return t.join(`
`).trim()}async function k({resume:e,vacancy:t}){let[n,r]=await Promise.all([y(),ne()]),i=v(await p(n,E({generationPrompt:r.generationPrompt,resume:e,vacancy:t})));if(!i)throw Error(`Модель вернула пустой ответ.`);return oe(O(i),r.letterSignature)}async function A(e){let t={...e,status:`processing`,updatedAt:new Date().toISOString()};await a(t);try{let[n,r]=await Promise.all([ae(),s(e.vacancyUrl)]);if(!n)throw Error(`Выберите резюме в sidepanel перед генерацией сопроводительного.`);if(!r)throw Error(`Вакансия не синхронизирована. Откройте страницу вакансии и подождите парсинг.`);let i=await k({resume:n,vacancy:r}),o={...t,status:`done`,updatedAt:new Date().toISOString(),result:{letter:i}};return await a(o),o}catch(e){let n={...t,status:`error`,updatedAt:new Date().toISOString(),error:e instanceof Error?e.message:`Не удалось сгенерировать сопроводительное.`};return await a(n),n}}var j=g(e=>{if(e!=null&&!(typeof e==`string`&&e.trim()===``))return e},_().optional());function M(e){return g(e=>Array.isArray(e)?e:[],h(e))}var N=x({id:_(),title:_(),source:_(),language:_(),selfAbout:j,experience:M(x({company:_(),position:_(),description:_(),startDate:_(),endDate:_()})),education:M(x({organization:_(),degree:_(),speciality:_()})),skills:M(_()),projects:M(x({name:_(),description:_(),link:j})),certifications:M(x({name:_(),description:_()}))}),P=`{
  "id": "string",
  "title": "string",
  "source": "string",
  "language": "string",
  "selfAbout": "string (optional)",
  "experience": [
    {
      "company": "string",
      "position": "string",
      "description": "string",
      "startDate": "string",
      "endDate": "string"
    }
  ],
  "education": [
    {
      "organization": "string",
      "degree": "string",
      "speciality": "string"
    }
  ],
  "skills": ["string"],
  "projects": [
    {
      "name": "string",
      "description": "string",
      "link": "string (optional)"
    }
  ] (optional, default []),
  "certifications": [
    {
      "name": "string",
      "description": "string"
    }
  ] (optional, default [])
}`,F=`Формат ответа:
- Верни только валидный JSON без markdown-блоков, комментариев и пояснений.
- Не оборачивай ответ в markdown code block — только сырой JSON-объект.
- Внутри строк JSON не используй реальные переносы строк: только \\n.
- Строго валидный JSON: экранируй переносы строк как \\n, без trailing commas.`;function I(e){return`${e.trim()}

Схема ответа (обязательная структура, не меняй поля и типы):
${P}

${F}`}async function L({sourceUrl:e,rawResumeText:t}){let{parsingPrompt:n}=await m();return[{role:`developer`,content:I(n)},{role:`user`,content:`sourceUrl: ${e}

Сырой текст резюме:
"""
${t}
"""`}]}function R(e){let t=e.replace(/^www\./i,``);if(/(\.|^)hh\.ru$/i.test(t))return`HeadHunter`;if(t.includes(`careerist.ru`))return`Careerist`;let n=t.split(`.`),r=n.length>=2?n[n.length-2]:void 0;return r?r.charAt(0).toUpperCase()+r.slice(1):t}async function z(e){let t=c(e,await u());if(t?.title)return t.title;if(t?.id)return t.id;try{return R(new URL(e).hostname)}catch{return`Unknown`}}function B(e){let t=e.trim(),n=t.match(/```(?:json)?\s*([\s\S]*?)\s*```/i);if(n?.[1])return n[1].trim();let r=t.indexOf(`{`),i=t.lastIndexOf(`}`);return r!==-1&&i>r?t.slice(r,i+1):t}function ue(e){let t=``,n=!1,r=!1;for(let i of e){if(r){t+=i,r=!1;continue}if(i===`\\`&&n){t+=i,r=!0;continue}if(i===`"`){n=!n,t+=i;continue}if(n){if(i===`
`){t+=`\\n`;continue}if(i===`\r`){t+=`\\r`;continue}if(i===`	`){t+=`\\t`;continue}}t+=i}return t}function V(e){return e.replace(/,\s*([}\]])/g,`$1`)}function H(e){let t=e.trim();if(!t)throw Error(`Модель вернула пустой ответ.`);let n=V(ue(B(t)));try{return JSON.parse(n)}catch(e){if(!n.trimEnd().endsWith(`}`)&&!n.trimEnd().endsWith(`]`))throw Error(`JSON резюме обрезан — генерация прервалась до конца. Попробуйте ещё раз или выберите более быструю модель.`);let t=e instanceof Error?e.message:`неизвестная ошибка`;throw Error(`Модель вернула невалидный JSON: ${t}`)}}var U=/(?:поднятие резюме|поднимать автоматически|видно всем работодателям|зарегистрированным на hh\.ru|можно сегодня в \d{1,2}:\d{2})/i,de=/^язык\s*:/i;function fe(e){let t=e?.trim();if(t&&!U.test(t)&&!de.test(t))return t}async function pe({sourceUrl:e,rawResumeText:t}){let n=await p(await y(),await L({sourceUrl:e,rawResumeText:t}),{temperature:.1}),r=v(n);if(!r)throw Error(`Модель вернула пустой ответ.`);if(n?.choices?.[0]?.finish_reason===`length`)throw Error(`Ответ модели обрезан по max tokens. Увеличьте max tokens в настройках LLM.`);let i=N.parse(H(r)),a=await z(e);return N.parse({...i,source:a,selfAbout:fe(i.selfAbout)})}async function me(t){let n={...t,status:`processing`,updatedAt:new Date().toISOString()};await e(n);try{let r=await pe({sourceUrl:t.sourceUrl,rawResumeText:t.rawResumeText}),{isUpdate:i}=await f(r),a={...n,status:`done`,updatedAt:new Date().toISOString(),result:{resume:r,isUpdate:i}};return await e(a),a}catch(t){let r={...n,status:`error`,updatedAt:new Date().toISOString(),error:t instanceof Error?t.message:`Не удалось обработать резюме.`};return await e(r),r}}x({url:_(),pageTitle:_().optional(),text:_(),updatedAt:_()}),x({url:_(),title:_(),text:_(),confirmedAt:_()}),x({status:ie([`idle`,`classifying`,`confirmed`,`rejected`,`error`]),url:_(),message:_().optional(),updatedAt:_()});var he=x({isVacancy:re()}),ge={systemPrompt:`Ты классификатор текста.
Получаешь фрагмент, спарсенный со страницы.
Определи, является ли этот текст описанием вакансии для найма сотрудника.

Верни только JSON:
{ "isVacancy": true }
или
{ "isVacancy": false }

Правила:
- true: есть признаки вакансии — должность, обязанности, требования, компания, условия работы.
- false: это не вакансия — резюме, новость, список вакансий, форма отклика, ошибка, пустой или нерелевантный текст.
- Не добавляй пояснений, только JSON.`};function _e(e){return[{role:`developer`,content:ge.systemPrompt},{role:`user`,content:`Текст для проверки:
"""
${e}
"""`}]}async function ve(e){let t=v(await p(await y(),_e(e)));if(!t)throw Error(`Модель вернула пустой ответ.`);let n=t.trim().toLowerCase();if(n===`true`)return{isVacancy:!0};if(n===`false`)return{isVacancy:!1};let r=H(t);return he.parse(r)}var W=``,G=!1,K=null,q=null;function ye(e){return`${e.url}::${e.text}`}async function J(e){let t=ye(e);if(!i(e.text)||t===W)return;if(G){K=e;return}G=!0;let n=new Date().toISOString();await b({status:`classifying`,url:e.url,message:`Проверяю, является ли текст вакансией...`,updatedAt:n}),await l({message:`Проверяю вакансию через LLM...`,type:`loading`});try{if(!(await ve(e.text)).isVacancy){W=t,await b({status:`rejected`,url:e.url,message:`LLM решила, что это не вакансия.`,updatedAt:new Date().toISOString()}),await l({message:`Текст не похож на вакансию. Последняя вакансия не обновлена.`,type:`error`});return}await te({url:e.url,title:e.pageTitle?.trim()||`Вакансия`,text:e.text,confirmedAt:new Date().toISOString()}),W=t,await b({status:`confirmed`,url:e.url,message:`Вакансия подтверждена и сохранена.`,updatedAt:new Date().toISOString()}),await l({message:`Вакансия подтверждена и сохранена как последняя.`,type:`success`})}catch(t){await b({status:`error`,url:e.url,message:t instanceof Error?t.message:`Не удалось проверить вакансию.`,updatedAt:new Date().toISOString()}),await l({message:t instanceof Error?t.message:`Не удалось проверить вакансию.`,type:`error`})}finally{G=!1;let e=K;K=null,e&&J(e)}}function be(e){i(e?.text)&&(q&&clearTimeout(q),q=setTimeout(()=>{J(e)},400))}var Y=!1,X=!1;async function Z(e){if(!(!e||e.status!==`pending`||Y)){Y=!0;try{await me(e)}finally{Y=!1}}}async function Q(e){if(!(!e||e.status!==`pending`||X)){X=!0;try{await A(e)}finally{X=!1}}}function $(e){be(e??void 0)}function xe(){chrome.storage.onChanged.addListener((e,t)=>{t===`local`&&(e.vacancyPageDraft&&$(e[d].newValue),e.resumeParseJob&&Z(e[n].newValue),e.coverLetterGenerateJob&&Q(e[r].newValue))}),o().then(e=>Z(e)),t().then(e=>Q(e)),ee().then(e=>$(e))}xe();